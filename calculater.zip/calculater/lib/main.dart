// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 5), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const CalculatorScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      // ignore: prefer_const_constructors
      body: Center(
        // ignore: prefer_const_constructors
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Text(
              "Welcome to Scientific Calculator",
              style: TextStyle(
                fontSize: 24,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 20),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen>
    with SingleTickerProviderStateMixin {
  String _output = "0";
  String _input = "";
  double _result = 0.0;

  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
        CurvedAnimation(parent: _animationController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == "C") {
        _input = "";
        _output = "0";
        _result = 0.0;
      } else if (buttonText == "=") {
        try {
          _output = _evaluate(_input);
          _result = double.parse(_output);
        } catch (e) {
          _output = "Error";
        }
      } else {
        _input += buttonText;
        _output = _input;
      }
    });
  }

  String _evaluate(String expression) {
    try {
      if (expression.contains("sin")) {
        return sin(_parseOperand(expression)).toString();
      } else if (expression.contains("cos")) {
        return cos(_parseOperand(expression)).toString();
      } else if (expression.contains("tan")) {
        return tan(_parseOperand(expression)).toString();
      } else {
        _result = _calculate(expression);
        return _result.toString();
      }
    } catch (e) {
      return "Error";
    }
  }

  double _parseOperand(String expression) {
    try {
      var operand = expression.replaceAll(RegExp(r'[^\d.]'), '');
      return double.parse(operand);
    } catch (e) {
      return 0.0;
    }
  }

  double _calculate(String expression) {
    try {
      final tokens = _tokenize(expression);
      return _compute(tokens);
    } catch (e) {
      return double.nan;
    }
  }

  List<String> _tokenize(String expression) {
    final tokens = <String>[];
    final buffer = StringBuffer();
    for (int i = 0; i < expression.length; i++) {
      if (RegExp(r'[0-9.]').hasMatch(expression[i])) {
        buffer.write(expression[i]);
      } else if (RegExp(r'[+\-*/]').hasMatch(expression[i])) {
        if (buffer.isNotEmpty) {
          tokens.add(buffer.toString());
          buffer.clear();
        }
        tokens.add(expression[i]);
      }
    }
    if (buffer.isNotEmpty) {
      tokens.add(buffer.toString());
    }
    return tokens;
  }

  double _compute(List<String> tokens) {
    List<String> newTokens = [];
    int i = 0;
    while (i < tokens.length) {
      if (tokens[i] == '*' || tokens[i] == '/') {
        final double num1 = double.parse(newTokens.removeLast());
        final double num2 = double.parse(tokens[++i]);
        newTokens.add((tokens[i - 1] == '*'
                ? num1 * num2
                : num2 != 0
                    ? num1 / num2
                    : double.infinity)
            .toString());
      } else {
        newTokens.add(tokens[i]);
      }
      i++;
    }

    double result = double.parse(newTokens[0]);
    for (i = 1; i < newTokens.length; i += 2) {
      if (newTokens[i] == '+') {
        result += double.parse(newTokens[i + 1]);
      } else if (newTokens[i] == '-') {
        result -= double.parse(newTokens[i + 1]);
      }
    }

    return result;
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final buttonFontSize = min(screenWidth, screenHeight) * 0.05;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Scientific Calculator"),
        centerTitle: true,
        backgroundColor: Colors.yellowAccent,
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                reverse: true,
                child: Text(
                  _input,
                  style: TextStyle(fontSize: buttonFontSize),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                reverse: true,
                child: Text(
                  _output,
                  style: TextStyle(fontSize: buttonFontSize * 2),
                ),
              ),
            ),
          ),
          const Divider(),
          Expanded(
            flex: 3,
            child: GridView.count(
              crossAxisCount: 4,
              childAspectRatio: screenWidth / (screenHeight / 2),
              padding: const EdgeInsets.all(4.0),
              children: <Widget>[
                _buildButton("7"),
                _buildButton("8"),
                _buildButton("9"),
                _buildButton("/"),
                _buildButton("4"),
                _buildButton("5"),
                _buildButton("6"),
                _buildButton("*"),
                _buildButton("1"),
                _buildButton("2"),
                _buildButton("3"),
                _buildButton("-"),
                _buildButton("0"),
                _buildButton("."),
                _buildButton("="),
                _buildButton("+"),
                _buildButton("C"),
                _buildButton("sin"),
                _buildButton("cos"),
                _buildButton("tan"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButton(String buttonText) {
    return GestureDetector(
      onTapDown: (_) => _animationController.forward(),
      onTapUp: (_) => _animationController.reverse(),
      onTapCancel: () => _animationController.reverse(),
      onTap: () => _buttonPressed(buttonText),
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          margin: const EdgeInsets.all(4.0),
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Text(
              buttonText,
              style: const TextStyle(fontSize: 20.0),
            ),
          ),
        ),
      ),
    );
  }
}
